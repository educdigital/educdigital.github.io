const aulas = [
{
id:1,
titulo:"Introdução à Segurança Digital",
data:"00-00-2026",
professor:"Profa. Ericka",
categoria:"Segurança",
imagem:"imgs/img1.jpg",
descricao:"Discussão sobre proteção de dados e boas práticas online."
},
{
id:2,
titulo:"HTML Básico",
data:"00-00-2026",
professor:"Profa. Ericka",
categoria:"Programação",
imagem:"imgs/img1.jpg",
descricao:"Estrutura básica de um site."
}
];

const eventos = [
{data:"2026-03-10",titulo:"Aula Segurança",tipo:"aula",descricao:"Aula sobre segurança digital"},
{data:"2026-03-20",titulo:"Entrega HTML",tipo:"tarefa",descricao:"Entrega do exercício"},
{data:"2026-04-05",titulo:"Workshop IA",tipo:"evento",descricao:"Workshop especial"}
];
